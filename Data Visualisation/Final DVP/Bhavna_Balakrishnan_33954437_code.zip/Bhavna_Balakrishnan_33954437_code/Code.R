library(shiny)
library(shinydashboard)
library(readxl)
library(dplyr)
library(tidyr)
library(plotly)
library(lubridate)

# Load the data for measures
aus_data <- read_excel("aus.xlsx", sheet = "measure")
ind_data <- read_excel("ind.xlsx", sheet = "measure")

# Load the data for performance for part 2
aus_performance_daily <- read_excel("aus.xlsx", sheet = "Performance Daily")
aus_performance_monthly <- read_excel("aus.xlsx", sheet = "Performance_Monthly")
aus_daily_avg <- read_excel("aus.xlsx", sheet = "daily_avg")
aus_monthly_avg <- read_excel("aus.xlsx", sheet = "monthly_avg")

ind_performance_daily <- read_excel("ind.xlsx", sheet = "Performance_Daily")
ind_performance_monthly <- read_excel("ind.xlsx", sheet = "Performance_Monthly")
ind_daily_avg <- read_excel("ind.xlsx", sheet = "daily_avg")
ind_monthly_avg <- read_excel("ind.xlsx", sheet = "monthly_avg")

# Load interest rate data for Indian and Australian datasets
ind_interest <- read_excel("ind.xlsx", sheet = "interest")
aus_interest <- read_excel("aus.xlsx", sheet = "interest")

# Country Compare Data
country_compare_data <- read_excel("aus.xlsx", sheet = "countrycompare")

ui <- dashboardPage(
  dashboardHeader(title = "Banking Dashboard"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Project Summary", tabName = "summary", icon = icon("dashboard")),
      menuItem("Banking Industry Snapshot", tabName = "industry_snapshot", icon = icon("bank")),
      menuItem("Performance Overview", tabName = "performance_overview", icon = icon("chart-line")),
      menuItem("Volatility Analysis", tabName = "volatility_analysis", icon = icon("exclamation")),
      menuItem("Interest Rate Relationship", tabName = "interest_rate_relationship", icon = icon("percentage")),
      menuItem("Country Compare", tabName = "country_compare", icon = icon("globe"))
    )
  ),
  dashboardBody(
    tabItems(
      tabItem(tabName = "summary",
              div(class = "summary-content",
                  # source:https://www.ausbanking.org.au/a-strong-financial-system/
                  img(src = "banking.jpeg", class = "ribbon-image"),
                  div(class = "summary-box",
                      h2("Project Summary"),
                      p("The Banking Industry plays a crucial role in a country’s economy which makes it important to understand how they are performing.
                      This project is aimed towards potential investors and financial analysts to help them make informed decisions on their investments
                        by providing them information on not only the rewrads but also the risks associated with investments in these banks.For the purpose of this assignment,
                        we will be further scrutinizing historical stock data from years 2019-2023"),
                      h2("Motivation"),
                      p("I have a vested interest in this project as a former Finance student with work experience in the Banking Industry.
                      The resources used are from extremely reliable sources such as YahooFinance,BSE and the companies own annual reports and press releases"),
                      h2("Takeaways"),
                      p("The key takeaways from this project are to help aid potential investors with aid of visual tools that are intuitive and interactive.
                        This makes ease of understanding the broader picture of the Bank Performance much simpler.")
                  )
              )
      ),
      tabItem(tabName = "industry_snapshot",
              h2("Banking Industry Snapshot"),
              fluidRow(
                column(4,
                       selectInput("country", "Select Country:", 
                                   choices = c("Australia", "India")),
                       radioButtons("measure", "Select Measure:",
                                    choices = list("Market Capitalization" = "marketcap",
                                                   "PAT" = "PAT",
                                                   "ROA" = "ROA",
                                                   "EPS" = "EPS"))
                ),
                column(8,
                       plotlyOutput("measurePlot"),
                       uiOutput("measureDescription"),
                       uiOutput("measureExplanation")
                )
              )
      ),
      tabItem(tabName = "performance_overview",
              h2("Performance Overview"),
              fluidRow(
                column(4,
                       selectInput("performance_country", "Select Country:",
                                   choices = c("Australia", "India", "Both")),
                       radioButtons("performance_measure", "Select Measure:",
                                    choices = list("Monthly" = "monthly", "Yearly" = "yearly")),
                       sliderInput("year_range", "Select Year Range:",
                                   min = 2019, max = 2023, value = c(2019, 2023), sep = "")
                ),
                column(8,
                       plotlyOutput("performancePlot"),
                       uiOutput("performanceDescription")
                )
              )
      ),
      tabItem(tabName = "volatility_analysis",
              h2("Volatility Analysis"),
              fluidRow(
                column(6,
                       selectInput("volatility_country", "Select Country:",
                                   choices = c("Australia", "India")),
                       uiOutput("bankSelect")
                ),
                column(6,
                       plotlyOutput("volatilityPlot"),
                       uiOutput("volatilityExplanation")
                )
              )
      ),
      tabItem(tabName = "interest_rate_relationship",
              h2("Interest Rate Relationship"),
              plotlyOutput("interestPlot"),
              uiOutput("relationship")
      ),
      tabItem(tabName = "country_compare",
              h2("Country Comparison"),
              selectInput("compare_aspect", "Choose Aspect to Compare:", choices = c("Performance", "Volatility")),
              plotlyOutput("comparisonPlot"),
              uiOutput("conclusion")
      )
    )
  ))


server <- function(input, output, session) {
  # Volatility Analysis: Plotting for all banks based on country selection
  output$volatilityPlot <- renderPlotly({
    req(input$volatility_country)  # Ensure that a country has been selected
    
    # Determine which dataset to use based on country selection
    if (input$volatility_country == "Australia") {
      data <- aus_performance_monthly
    } else {
      data <- ind_performance_monthly
    }
    
    # Reshape data to long format for plotting
    boxplot_data <- data %>%
      pivot_longer(cols = -Date, names_to = "Bank", values_to = "Performance") %>%
      group_by(Bank) %>%
      summarise(Performance = list(Performance)) %>%
      unnest(cols = c(Performance))
    
    # Generate box plot
    plot_ly(data = boxplot_data, y = ~Performance, x = ~Bank, type = 'box',
            color = ~Bank, colors = "Set1") %>%
      layout(title = paste("Volatility Analysis for", input$volatility_country, "Banks"),
             yaxis = list(title = "Performance"),
             xaxis = list(title = "Bank"))
  })
  
  output$volatilityExplanation <- renderUI({
    HTML(paste("<p>The volatility analysis for banks in Australia and India shows performance variability over time. In Australia, banks like ANZ, Bendigo, Commonwealth, NAB, and Westpac display performance spreads ranging up to 40 units with medians near zero, reflecting market stability. In contrast, Indian banks like AXIS, HDFC, ICICI, KOTAK, and SBI show greater variability, with some extending below -20 and others above 20, indicating more significant fluctuations in their performances. This comparative visualization highlights the differences in financial stability and market behavior between the two countries’ banking sectors."))
  })
  
  # Data for Banking Industry Snapshot
  selectedData <- reactive({
    if (input$country == "Australia") {
      aus_data
    } else {
      ind_data
    }
  })
  
  output$measurePlot <- renderPlotly({
    data <- selectedData()
    data <- data %>% arrange(desc(!!sym(input$measure)))
    
    if (input$measure == "marketcap") {
      plot <- plot_ly(data, labels = ~Bank, values = ~marketcap, type = 'pie', hole = 0.5) %>%
        layout(title = paste("Market Capitalization in billion $ in", input$country),
               showlegend = TRUE)
      plot
    } else {
      plot <- ggplot(data, aes(y = reorder(Bank, get(input$measure)), x = get(input$measure), fill = Bank, text = paste("Bank:", Bank, "<br>", input$measure, ":", get(input$measure)))) +
        geom_bar(stat = "identity") +
        theme_minimal() +
        scale_fill_brewer(palette = "Set3") +
        labs(title = paste(input$measure, "in", input$country), x = input$measure, y = "Bank") +
        coord_flip()
      ggplotly(plot, tooltip = "text")
    }
  })
  
  output$measureDescription <- renderUI({
    measure_desc <- switch(input$measure,
                           "marketcap" = "Market Capitalization represents the total market value of a company's outstanding shares of stock.",
                           "PAT" = "PAT (Profit After Tax) indicates the net profitability of the company after all taxes have been deducted.",
                           "ROA" = "ROA (Return on Assets) measures the profitability of a company relative to its total assets.",
                           "EPS" = "EPS (Earnings Per Share) calculates the company's profit divided by the outstanding shares of its common stock."
    )
    p(measure_desc)
  })
  
  output$measureExplanation <- renderUI({
    HTML(paste("<p>From looking at the Australian Banks, we see that CBA has taken the lead on multiple fronts making it appear to be the main leader except for when it comes to PAT where NAB takes first place.
               In the Indian Context, every measure has a different Bank taking the lead implying healthy competition among the top 5."))
  })
  # Data for Performance Overview
  selectedPerformanceData <- reactive({
    country <- input$performance_country
    measure <- input$performance_measure
    year_range <- input$year_range
    
    if (country == "Australia" && measure == "monthly") {
      data <- aus_performance_monthly %>%
        filter(year(Date) >= year_range[1] & year(Date) <= year_range[2]) %>%
        pivot_longer(-Date, names_to = "Bank", values_to = "Average")
    } else if (country == "Australia" && measure == "yearly") {
      data <- aus_monthly_avg %>%
        filter(year(Date) >= year_range[1] & year(Date) <= year_range[2]) %>%
        pivot_longer(-Date, names_to = "Bank", values_to = "Average")
    } else if (country == "India" && measure == "monthly") {
      data <- ind_performance_monthly %>%
        filter(year(Date) >= year_range[1] & year(Date) <= year_range[2]) %>%
        pivot_longer(-Date, names_to = "Bank", values_to = "Average")
    } else if (country == "India" && measure == "yearly") {
      data <- ind_monthly_avg %>%
        filter(year(Date) >= year_range[1] & year(Date) <= year_range[2]) %>%
        pivot_longer(-Date, names_to = "Bank", values_to = "Average")
    } else if (country == "Both" && measure == "monthly") {
      aus_data <- aus_daily_avg %>%
        mutate(Date = floor_date(Date, "month")) %>%
        group_by(Date) %>%
        summarize(Average = mean(Average, na.rm = TRUE)) %>%
        mutate(Country = "Australia")
      ind_data <- ind_daily_avg %>%
        mutate(Date = floor_date(Date, "month")) %>%
        group_by(Date) %>%
        summarize(Average = mean(Average, na.rm = TRUE)) %>%
        mutate(Country = "India")
      data <- bind_rows(aus_data, ind_data) %>%
        filter(year(Date) >= year_range[1] & year(Date) <= year_range[2])
    } else if (country == "Both" && measure == "yearly") {
      data <- bind_rows(
        aus_monthly_avg %>%
          mutate(Country = "Australia"),
        ind_monthly_avg %>%
          mutate(Country = "India")
      ) %>%
        filter(year(Date) >= year_range[1] & year(Date) <= year_range[2])
    }
    return(data)
  })
  output$performancePlot <- renderPlotly({
    data <- selectedPerformanceData()
    if (input$performance_country == "Australia" || input$performance_country == "India") {
      plot <- ggplot(data, aes(x = Date, y = Average, color = Bank)) +
        geom_line() +
        theme_minimal() +
        labs(title = paste(input$performance_measure, "Performance of", input$performance_country, "Banks"), x = "Date", y = "Performance")
    } else {
      plot <- ggplot(data, aes(x = Date, y = Average, color = Country)) +
        geom_line() +
        theme_minimal() +
        labs(title = paste(input$performance_measure, "Performance Comparison of Australian and Indian Banks"), x = "Date", y = "Average Performance")
    }
    
    ggplotly(plot)
  })
  output$performanceDescription <- renderUI({
    HTML(paste("<p>Both monthly and yearly performances exhibit significant fluctuations, with noticeable peaks and troughs. 
               The overall trend shows similar patterns for both countries.The main noticeable trend we can see is for both countries having a decline in 2020, most
               likely caused by the onset of the COVID-19 Pandemic. They have also managed to recover in time and continue to fluctuate."))
  })
  # Interest
  output$interestPlot <- renderPlotly({
    # Combine both datasets with a new 'Country' column
    combined_data <- bind_rows(
      ind_interest %>% mutate(Country = "India"),
      aus_interest %>% mutate(Country = "Australia")
    )
    
    # Scatter plot
    plot <- ggplot(combined_data, aes(x = Rate, y = Return, color = Country)) +
      geom_point() +
      geom_smooth(method = "lm", formula = y ~ x, se = FALSE) +
      labs(title = "Interest Rate vs Return", x = "Interest Rate", y = "Return") +
      theme_minimal() +
      scale_color_brewer(palette = "Set1")
    
    ggplotly(plot)
  })
  
  output$relationship <- renderUI({
    HTML(paste("<p>Linear trend lines are included for both countries, suggesting the direction and strength of the relationship. The plot indicates that for both countries, as interest rates increase, the returns do not show a consistent increase or decrease, suggesting a weak or no correlation between these two variables."))
  })
  #Country Compare
  observeEvent(input$compare_aspect, {
    if (input$compare_aspect == "Performance") {
      output$comparisonPlot <- renderPlotly({
        plot <- ggplot(country_compare_data, aes(x = Date)) +
          geom_line(aes(y = Australia, color = "Australia")) +
          geom_line(aes(y = India, color = "India")) +
          labs(title = "Performance Comparison between Australia and India",
               x = "Date", y = "Performance",
               color = "Country") +
          theme_minimal()
        
        ggplotly(plot)
      })
    } else if (input$compare_aspect == "Volatility") {
      output$comparisonPlot <- renderPlotly({
        country_compare_data_long <- country_compare_data %>%
          pivot_longer(cols = c(Australia, India), names_to = "Country", values_to = "Performance")
        
        country_variances <- country_compare_data_long %>%
          group_by(Country) %>%
          summarise(Variance = var(Performance, na.rm = TRUE))
        
        plot <- ggplot(country_compare_data_long, aes(x = Country, y = Performance, fill = Country)) +
          geom_violin() +
          geom_text(data = country_variances, aes(label = sprintf("Variance: %.2f", Variance), y = Inf), vjust = -0.5) +
          labs(title = "Volatility Comparison between Australia and India",
               x = "Country", y = "Performance") +
          theme_minimal()
        
        ggplotly(plot)
      })
    }
  })
  output$conclusion <- renderUI({
    HTML(paste("<p>The performance comparison between Australian and Indian banks from 2020 to 2024 shows fluctuating monthly performance metrics, with both countries experiencing similar trends and volatility. The volatility comparison, depicted through violin plots, further emphasizes the similar range of performance variability between the two countries, although the distributions slightly differ. Overall, the banks in both countries exhibit a consistent performance with notable swings in certain periods, indicating a comparable investment risk and behavior in the banking sectors of Australia and India."))
  })
}


shinyApp(ui, server)