library(shiny)
library(ggplot2)
library(dplyr)
library(leaflet)

# Read the data from CSV file
data <- read.csv("Victoria_Accident_Data_FIT5147S12024PE2v2.csv")

# Rename columns
colnames(data) <- c("ACCIDENT_NO", "ACCIDENT_DATE", "ACCIDENT_TIME", "DAY_WEEK_DESC",
                    "ACCIDENT_TYPE", "ACCIDENT_TYPE_DESC", "SEVERITY_RANK", 
                    "LIGHT_CONDITION_DESC", "LGA_NAME", "ROAD_GEOMETRY_DESC", 
                    "SPEED_ZONE", "LATITUDE", "LONGITUDE")

# Convert SPEED_ZONE to factor
data$SPEED_ZONE <- as.factor(data$SPEED_ZONE)

# Define UI
ui <- fixedPage(
  #TITLE
  titlePanel("Accidents in Victoria"),
  # VIS 1 and VIS 2 Section
  fluidRow(
    column(width = 6,
           h3("VIS 1: Accidents by Light Condition and Speed Zone"),
           plotOutput("vis1_plot"),
           p("Map showing Accidents that took place based on light conditions at different speed zones")
    ),
    column(width = 6,
           h3("VIS 2: Hourly number of Accidents in Top 4 Speed Zones"),
           plotOutput("vis2_plot"),
           p("This plot shows the number of accidents by hour for the top 4 speed zones.")
    )
  ),
  
  # Interactive Map Section
  fluidRow(
    titlePanel("Interactive Map of Accidents"),
    sidebarLayout(
      sidebarPanel(
        sliderInput("severity_slider", "Select Severity Rank:",
                    min = 1, max = 4, value = c(1, 4), step = 1),
        checkboxGroupInput("daynight_checkbox", "Select Light Conditions:",
                           choices = c("Day", "Dusk/Dawn", "Night"), selected = c("Day", "Dusk/Dawn", "Night"))
      ),
      mainPanel(
        leafletOutput("map"),
        br(),
        p("Description: Map displaying the Accidents that happened in Victoria by Light Conditions and adjusted by severity.Click on the spot to know more")
      )
    )
  )
)

# Define server logic
server <- function(input, output) {
  # VIS 1: Accidents by Light Condition and Speed Zone
  output$vis1_plot <- renderPlot({
    ggplot(data, aes(x = LIGHT_CONDITION_DESC, fill = SPEED_ZONE)) +
      geom_bar() +
      labs(title = "Accidents by Light Condition and Speed Zone",
           x = "Light Condition",
           y = "Number of Accidents",
           fill = "Speed Zone") +
      theme_minimal()
  })
  
  # VIS 2: Number of accidents by hour for top 4 speed zones
  # Determine top 4 speed zones where accidents occurred the most
  top_speed_zones <- data %>%
    group_by(SPEED_ZONE) %>%
    summarise(Count = n()) %>%
    arrange(desc(Count)) %>%
    top_n(4) %>%
    pull(SPEED_ZONE)
  
  # Filter data for accidents occurring in top 4 speed zones
  top_speed_zones_data <- data %>%
    filter(SPEED_ZONE %in% top_speed_zones)
  
  # Extract hour from ACCIDENT_TIME
  top_speed_zones_data$Hour <- as.integer(substring(top_speed_zones_data$ACCIDENT_TIME, 1, 2))
  
  # Aggregate number of accidents for each hour in each of the top 4 speed zones
  hourly_accidents <- top_speed_zones_data %>%
    group_by(Hour, SPEED_ZONE) %>%
    summarise(Count = n())
  
  # Create the line chart for VIS 2
  output$vis2_plot <- renderPlot({
    ggplot(hourly_accidents, aes(x = Hour, y = Count, color = SPEED_ZONE)) +
      geom_line() +
      labs(title = "Number of Accidents by Hour for Top 4 Speed Zones",
           x = "Hour",
           y = "Number of Accidents",
           color = "Speed Zone") +
      theme_minimal()
  })
  
  # Interactive Map
  output$map <- renderLeaflet({
    filtered_data <- data[data$SEVERITY_RANK >= input$severity_slider[1] & 
                            data$SEVERITY_RANK <= input$severity_slider[2] &
                            data$LIGHT_CONDITION_DESC %in% input$daynight_checkbox, ]
    
    # Include additional conditions under 'Night' checkbox
    filtered_data$LIGHT_CONDITION_DESC[filtered_data$LIGHT_CONDITION_DESC %in% c("Dark No Street Lights", "Dark Street Lights On", "Dark Street Lights Off")] <- "Night"
    
    leaflet(filtered_data) %>%
      addTiles() %>%
      addCircleMarkers(~LONGITUDE, ~LATITUDE, 
                       color = ~LIGHT_CONDITION_DESC, 
                       fillColor = ~ifelse(LIGHT_CONDITION_DESC == "Day", "blue", 
                                           ifelse(LIGHT_CONDITION_DESC == "Dusk/Dawn", "orange", "red")),
                       radius = ~10 - SEVERITY_RANK * 2,  # Adjust the radius based on severity_rank
                       opacity = 0.7, 
                       fillOpacity = 0.7,
                       popup = ~paste("Date: ", ACCIDENT_DATE, "<br>",
                                      "Accident Type: ", ACCIDENT_TYPE_DESC, "<br>",
                                      "Light Condition: ", LIGHT_CONDITION_DESC, "<br>",
                                      "Road Geometry: ", ROAD_GEOMETRY_DESC, "<br>",
                                      "Speed Zone: ", SPEED_ZONE, "<br>",
                                      "Severity Rank: ", SEVERITY_RANK)) %>%
      addLegend(position = "bottomright", colors = c("blue", "orange", "red"), 
                labels = c("Day", "Dusk/Dawn", "Night"), title = "Light Condition",
                opacity = 0.7)
  })
}

# Run the application
shinyApp(ui = ui, server = server)

